package formulario;
public class Formulario {

    
    public static void main(String[] args) {
        System.out.println("hello World");    }
    
}
