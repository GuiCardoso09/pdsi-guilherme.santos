package Formularios;
public class Calculo extends javax.swing.JFrame {

    public Calculo() {
        initComponents();
        Desabilitar();
    }

    void Desabilitar(){ 
        txt_n1.setEditable(false); 
        txt_n2.setEditable(false); 
        txt_res.setEditable(false); 
    } 
    void Habilitar(){ 
        txt_n1.setEditable(true); 
        txt_n2.setEditable(true); 
    txt_res.setEditable(true); 
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        try {
            jPanel1 =(javax.swing.JPanel)java.beans.Beans.instantiate(getClass().getClassLoader(), "Formularios.Calculo_jPanel1");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txt_n1 = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        txt_n2 = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        txt_res = new javax.swing.JTextArea();
        subtracao = new javax.swing.JButton();
        multiplicacao = new javax.swing.JButton();
        divisao = new javax.swing.JButton();
        nv_conta = new javax.swing.JButton();
        limp_conta = new javax.swing.JButton();
        sair = new javax.swing.JButton();
        retorno = new javax.swing.JButton();
        comparacao = new javax.swing.JButton();
        soma = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBackground(new java.awt.Color(255, 255, 0));
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("N1");

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("N2");

        jLabel3.setBackground(new java.awt.Color(240, 240, 240));
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Resultado:");

        jScrollPane3.setBackground(java.awt.Color.white);
        jScrollPane3.setForeground(java.awt.Color.black);
        jScrollPane3.setMaximumSize(new java.awt.Dimension(15, 20));

        txt_n1.setBackground(java.awt.Color.white);
        txt_n1.setColumns(20);
        txt_n1.setForeground(java.awt.Color.black);
        txt_n1.setRows(5);
        txt_n1.setWrapStyleWord(true);
        txt_n1.setCaretColor(java.awt.Color.white);
        jScrollPane3.setViewportView(txt_n1);

        jScrollPane5.setBackground(java.awt.Color.white);
        jScrollPane5.setForeground(java.awt.Color.black);
        jScrollPane5.setMaximumSize(new java.awt.Dimension(15, 20));

        txt_n2.setBackground(java.awt.Color.white);
        txt_n2.setColumns(20);
        txt_n2.setForeground(java.awt.Color.black);
        txt_n2.setRows(5);
        txt_n2.setWrapStyleWord(true);
        txt_n2.setCaretColor(java.awt.Color.white);
        jScrollPane5.setViewportView(txt_n2);

        jScrollPane6.setBackground(java.awt.Color.white);
        jScrollPane6.setForeground(java.awt.Color.black);
        jScrollPane6.setMaximumSize(new java.awt.Dimension(15, 20));

        txt_res.setBackground(java.awt.Color.white);
        txt_res.setColumns(20);
        txt_res.setForeground(java.awt.Color.black);
        txt_res.setRows(5);
        txt_res.setWrapStyleWord(true);
        txt_res.setCaretColor(java.awt.Color.white);
        jScrollPane6.setViewportView(txt_res);

        subtracao.setText("-");
        subtracao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subtracaoActionPerformed(evt);
            }
        });

        multiplicacao.setText("x");
        multiplicacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                multiplicacaoActionPerformed(evt);
            }
        });

        divisao.setText("/");
        divisao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                divisaoActionPerformed(evt);
            }
        });

        nv_conta.setText("Novo");
        nv_conta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nv_contaActionPerformed(evt);
            }
        });

        limp_conta.setText("Limpar");
        limp_conta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limp_contaActionPerformed(evt);
            }
        });

        sair.setText("Sair");
        sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairActionPerformed(evt);
            }
        });

        retorno.setText("Retornar");
        retorno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                retornoActionPerformed(evt);
            }
        });

        comparacao.setText("Comparação");

        soma.setText("+");
        soma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                somaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(121, 121, 121)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)))
                        .addGap(558, 558, 558))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(nv_conta, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(limp_conta)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(sair, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(soma)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(subtracao, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(multiplicacao, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(divisao, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(407, 407, 407)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(retorno)
                    .addComponent(comparacao))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(subtracao)
                    .addComponent(multiplicacao)
                    .addComponent(divisao)
                    .addComponent(retorno)
                    .addComponent(soma))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nv_conta)
                    .addComponent(limp_conta)
                    .addComponent(sair)
                    .addComponent(comparacao))
                .addContainerGap(71, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void somaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_somaActionPerformed
       int x, y, z; //Variáveis de apoio
       String r; //Receber valor
       
       x = Integer.parseInt(txt_n1.getText());
       y = Integer.parseInt(txt_n2.getText());
       
       z = x + y;
       r = String.valueOf(z); //Vira String para que o campo de texto seja aceito
       txt_res.setText(r); //Campo de resposta recebendo valor
    }//GEN-LAST:event_somaActionPerformed
    private void divisaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_divisaoActionPerformed
 int x, y, z; //Variáveis de apoio
       String r; //Receber valor
       
       x = Integer.parseInt(txt_n1.getText());
       y = Integer.parseInt(txt_n2.getText());
       
       z = x / y;
       r = String.valueOf(z); //Vira String para que o campo de texto seja aceito
       txt_res.setText(r); //Campo de resposta recebendo valor
    }//GEN-LAST:event_divisaoActionPerformed

    private void nv_contaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nv_contaActionPerformed
       Habilitar();
    }//GEN-LAST:event_nv_contaActionPerformed

    private void subtracaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subtracaoActionPerformed
  int x, y, z; //Variáveis de apoio
       String r; //Receber valor
       
       x = Integer.parseInt(txt_n1.getText());
       y = Integer.parseInt(txt_n2.getText());
       
       z = x - y;
       r = String.valueOf(z); //Vira String para que o campo de texto seja aceito
       txt_res.setText(r); //Campo de resposta recebendo valor
    }//GEN-LAST:event_subtracaoActionPerformed

    private void multiplicacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_multiplicacaoActionPerformed
  int x, y, z; //Variáveis de apoio
       String r; //Receber valor
       
       x = Integer.parseInt(txt_n1.getText());
       y = Integer.parseInt(txt_n2.getText());
       
       z = x * y;
       r = String.valueOf(z); //Vira String para que o campo de texto seja aceito
       txt_res.setText(r); //Campo de resposta recebendo valor
    }//GEN-LAST:event_multiplicacaoActionPerformed

    private void sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_sairActionPerformed

    private void limp_contaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limp_contaActionPerformed
    txt_n1.setText(""); 
    txt_n2.setText(""); 
    txt_res.setText(""); 
    }//GEN-LAST:event_limp_contaActionPerformed

    private void retornoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_retornoActionPerformed
    Calculo formulario = new Calculo();
    formulario.setVisible(true);
    dispose();
    }//GEN-LAST:event_retornoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Calculo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Calculo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Calculo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Calculo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Calculo().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton comparacao;
    private javax.swing.JButton divisao;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JButton limp_conta;
    private javax.swing.JButton multiplicacao;
    private javax.swing.JButton nv_conta;
    private javax.swing.JButton retorno;
    private javax.swing.JButton sair;
    private javax.swing.JButton soma;
    private javax.swing.JButton subtracao;
    private javax.swing.JTextArea txt_n1;
    private javax.swing.JTextArea txt_n2;
    private javax.swing.JTextArea txt_res;
    // End of variables declaration//GEN-END:variables
}


